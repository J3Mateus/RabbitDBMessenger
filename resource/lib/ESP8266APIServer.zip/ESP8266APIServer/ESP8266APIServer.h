#ifndef ESP8266_API_SERVER_H
#define ESP8266_API_SERVER_H

#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <Arduino.h>

class ESP8266APIServer {
public:
    ESP8266APIServer(int port, ESP8266WiFiClass& wifi);
    void begin();
    void handleClient();

    void setFirmwareUrl(const char* firmwareUrl);
    const char* getFirmwareUrl();

private:
    ESP8266WebServer server;
    const char* firmwareUrl;
    ESP8266WiFiClass& wifi;

    void setupRoutes();
    void handlePostRequest();
    void connectToWiFi(); // Declaração da função connectToWiFi()
};

#endif
