#include "ESP8266APIServer.h"
#include <ArduinoJson.h>
#include <ESP8266httpUpdate.h>


ESP8266APIServer::ESP8266APIServer(int port, ESP8266WiFiClass& wifi)
    : server(port), wifi(wifi) {}

void ESP8266APIServer::begin() {
    wifi.mode(WIFI_STA); // Configura o ESP8266 como cliente

    connectToWiFi(); // Chamada para connectToWiFi()

    setupRoutes();
    server.begin();
}

void ESP8266APIServer::handleClient() {
    server.handleClient();
}

void ESP8266APIServer::setupRoutes() {
    server.on("/send/version", HTTP_POST, std::bind(&ESP8266APIServer::handlePostRequest, this));
}

void ESP8266APIServer::handlePostRequest() {
    if (server.hasArg("plain")) {
        String jsonStr = server.arg("plain");
        DynamicJsonDocument jsonDoc(256);
        DeserializationError error = deserializeJson(jsonDoc, jsonStr);

        if (error) {
            server.send(400, "text/plain", "Erro ao processar JSON");
            return;
        }

        const char* firmwareUrl = jsonDoc["url"];

        if (strlen(firmwareUrl) == 0) {
            server.send(400, "text/plain", "URL do firmware ausente no JSON");
            return;
        }
        Serial.print("URL do firmware: ");
        Serial.println(firmwareUrl);
        WiFiClient client;
        Serial.println("Iniciando atualização do firmware...");
        t_httpUpdate_return ret = ESPhttpUpdate.update(client, firmwareUrl);
        switch (ret) {
            case HTTP_UPDATE_FAILED:
                Serial.println("Falha ao atualizar o firmware");
                server.send(500, "text/plain", "Falha ao atualizar o firmware");
                break;
            case HTTP_UPDATE_NO_UPDATES:
                Serial.println("Nenhuma atualização disponível para o firmware");
                server.send(304, "text/plain", "Nenhuma atualização disponível para o firmware");
                break;
            case HTTP_UPDATE_OK:
                Serial.println("Firmware atualizado com sucesso. Reiniciando...");
                server.send(200, "text/plain", "Firmware atualizado com sucesso. Reiniciando...");
                ESP.restart();
                break;
        }
    } else {
        server.send(400, "text/plain", "Nenhum JSON recebido na requisição POST");
    }
}

void ESP8266APIServer::connectToWiFi() {
    wifi.begin("Rede_Wifi", "35293570"); // Substitua "SSID" e "password" pelos seus valores
    Serial.println("Conectando à rede Wi-Fi");

    while (wifi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println("");
    Serial.println("Conectado à rede Wi-Fi");
    Serial.println("Endereço IP: " + WiFi.localIP().toString());
}

void ESP8266APIServer::setFirmwareUrl(const char* firmwareUrl) {
    this->firmwareUrl = firmwareUrl;
}

const char* ESP8266APIServer::getFirmwareUrl() {
    return firmwareUrl;
}
